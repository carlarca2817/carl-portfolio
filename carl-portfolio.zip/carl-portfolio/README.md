# Carl Portfolio — Fullstack (Vite + Express)

## Quick start
1. Open this folder in VS Code
2. Install deps
   ```bash
   cd backend && npm install
   cd ../frontend && npm install
   ```
3. Create env files
   - `backend/.env` (copy from `.env.example`)
   - `frontend/.env`
4. Run servers
   ```bash
   cd backend && npm start
   # open a new terminal
   cd frontend && npm run dev
   ```

## Frontend (.env)
```env
VITE_API_URL=http://localhost:5000
```

## Backend (.env.example)
```env
EMAIL_USER=yourgmail@gmail.com
EMAIL_PASS=your_gmail_app_password
CLIENT_URL=http://localhost:5173
PORT=5000
```
