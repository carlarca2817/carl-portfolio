import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import {
  Brain,
  Workflow,
  FileCode,
  Layers,
  Settings2,
  Rocket,
  Link as LinkIcon,
  Mail,
  ExternalLink,
  CheckCircle2,
  Search,
  BookOpen,
  ShieldCheck,
  Gauge,
  Sparkles,
} from "lucide-react";

// ---------- helpers ----------
const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 16 },
  whileInView: { opacity: 1, y: 0 },
  transition: { duration: 0.6, ease: "easeOut", delay },
  viewport: { once: true, margin: "-80px" },
});

const SectionTitle = ({ icon: Icon, title, subtitle }) => (
  <div className="mb-6 flex items-center gap-3">
    <div className="rounded-2xl bg-primary/10 p-2">
      <Icon className="h-5 w-5" />
    </div>
    <div>
      <h2 className="text-xl font-bold leading-tight md:text-2xl">{title}</h2>
      {subtitle && (
        <p className="text-sm text-muted-foreground">{subtitle}</p>
      )}
    </div>
  </div>
);

// ---------- data ----------
const nav = [
  { href: "#about", label: "About" },
  { href: "#skills", label: "Skills" },
  { href: "#frameworks", label: "Frameworks" },
  { href: "#projects", label: "Projects" },
  { href: "#case-study", label: "Case Study" },
  { href: "#tools", label: "Tools" },
  { href: "#contact", label: "Contact" },
];

const skills = [
  {
    icon: Brain,
    title: "Prompt Engineering & AI Systems",
    points: [
      "Zero-shot, Few-shot, and Chain-of-Thought (CoT) design",
      "ROSES, FORMAT, VOICE, META, IMPROVE frameworks",
      "Context window optimization for long-form reasoning",
      "Error handling, bias mitigation, and structured outputs",
    ],
  },
  {
    icon: Workflow,
    title: "Persona & Context Engineering",
    points: [
      "Expert personas aligned to brand voice and goals",
      "Reasoning pattern & tone calibration",
      "Strategic constraint design for focused outputs",
      "Information hierarchy & context ordering",
    ],
  },
  {
    icon: Layers,
    title: "Modular Systems & Libraries",
    points: [
      "Reusable modules, templates, and variable systems",
      "Format libraries for consistent deliverables",
      "Self-verification & fallback protocols",
      "Scalable prompt architecture for teams",
    ],
  },
];

const frameworks = [
  {
    icon: Settings2,
    title: "ROSES++",
    body:
      "Enhanced ROSES with bias mitigation, structured outputs, and modular personas for repeatable excellence.",
    chips: ["Role", "Objective", "Scenario", "Expected", "Steps"],
  },
  {
    icon: FileCode,
    title: "FORMAT-X",
    body:
      "Strict output control: tables, hierarchies, and verification gates for clean, ready-to-use deliverables.",
    chips: ["Structure", "Hierarchy", "Markup", "Arrangement", "Terminology"],
  },
  {
    icon: Brain,
    title: "VOICE Persona Engine",
    body:
      "Dynamic persona system tuning knowledge depth, tone, and reasoning for content, analytics, and strategy.",
    chips: ["Viewpoint", "Occupation", "Intelligence", "Communication", "Emphasis"],
  },
];

const projects = [
  {
    title: "YouTube Growth Strategy AI",
    metrics: [
      { label: "CTR", value: "+45%" },
      { label: "Watch Time", value: "+32%" },
    ],
    bullets: [
      "SEO strategist, scriptwriter, and engagement analyst personas",
      "Reusable templates for hooks, CTAs, and narrative arcs",
      "Automated title/thumbnail ideation with retention cues",
    ],
  },
  {
    title: "Automated Content Marketing Framework",
    metrics: [
      { label: "Editing Time", value: "-70%" },
      { label: "Ranking", value: "+6w gains" },
    ],
    bullets: [
      "ROSES++ + FORMAT-X for on-spec, SEO-ready articles",
      "Search-intent mapped topic generator",
      "Publication pipeline with quality gates",
    ],
  },
  {
    title: "AI-Powered Business Analysis Suite",
    metrics: [
      { label: "Forecast Accuracy", value: "+18%" },
      { label: "Workload", value: "-40%" },
    ],
    bullets: [
      "Few-shot prompts seeded with prior models",
      "CoT reasoning + self-check for hallucination control",
      "Scenario modeling & decision support",
    ],
  },
];

const tools = [
  "GPT-5, Claude, Gemini, LLaMA",
  "LangChain, OpenAI API, Zapier, Notion AI",
  "SurferSEO, SEMrush, Canva, Figma",
  "Shadcn/UI, Tailwind, Framer Motion, Lucide",
];

// ---------- component ----------
export default function PortfolioSite() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-muted/20 text-foreground">
      {/* Skip link */}
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-50 rounded-md bg-primary px-3 py-2 text-primary-foreground">
        Skip to content
      </a>

      {/* Header */}
      <header className="sticky top-0 z-30 backdrop-blur supports-[backdrop-filter]:bg-background/70 border-b">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2">
            <span className="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-primary/10">
              <Sparkles className="h-5 w-5" />
            </span>
            <div className="leading-tight">
              <div className="text-sm text-muted-foreground">Portfolio</div>
              <div className="font-semibold">Carl A.</div>
            </div>
          </div>

          <nav className="hidden gap-2 md:flex">
            {nav.map((item) => (
              <a key={item.href} href={item.href} className="rounded-xl px-3 py-2 text-sm text-muted-foreground hover:text-foreground">
                {item.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <Button asChild variant="default" className="rounded-2xl">
              <a href="#contact"><Mail className="mr-2 h-4 w-4" /> Contact</a>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <main id="main" className="mx-auto max-w-6xl px-4">
        <motion.section {...fadeUp(0)} className="mt-10 md:mt-14">
          <Card className="relative overflow-hidden rounded-3xl border bg-gradient-to-br from-primary/5 via-background to-background">
            <CardContent className="relative z-10 p-6 md:p-10">
              <div className="grid gap-6 md:grid-cols-2 md:items-center">
                <div>
                  <h1 className="text-2xl font-bold leading-tight md:text-4xl">
                     AI Prompt Engineer
                  </h1>
                  <p className="mt-2 max-w-prose text-sm text-muted-foreground md:text-base">
                    building advanced prompt systems, modular frameworks, and persona-driven AI that deliver on-spec, reliable outputs for content, strategy, and analytics.
                  </p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {["ROSES++", "FORMAT-X", "VOICE", "CoT", "Few-shot"].map((chip) => (
                      <Badge key={chip} variant="secondary" className="rounded-2xl">
                        {chip}
                      </Badge>
                    ))}
                  </div>
                  <div className="mt-6 flex flex-wrap gap-2">
                    <Button className="rounded-2xl" asChild>
                      <a href="#projects"><Rocket className="mr-2 h-4 w-4" /> View Projects</a>
                    </Button>
                    <Button className="rounded-2xl" variant="outline" asChild>
                      <a href="#frameworks"><Layers className="mr-2 h-4 w-4" /> Frameworks</a>
                    </Button>
                  </div>
                </div>
                <div className="relative order-first aspect-[4/3] overflow-hidden rounded-3xl bg-muted md:order-none">
                  {/* Decorative grid */}
                  <div className="absolute inset-0 bg-[radial-gradient(theme(colors.primary/20)_1px,transparent_1px)] [background-size:16px_16px]" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="rounded-3xl bg-background/70 p-4 shadow-xl ring-1 ring-black/5">
                      <div className="text-center">
                        <div className="text-xs uppercase tracking-wider text-muted-foreground">Signature System</div>
                        <div className="mt-1 font-semibold">CarlPrompt Framework™</div>
                        <Separator className="my-3" />
                        <ul className="text-left text-sm leading-relaxed text-muted-foreground">
                          <li className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4" /> Modular prompts</li>
                          <li className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4" /> Output control</li>
                          <li className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4" /> Bias mitigation</li>
                          <li className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4" /> Persona engine</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.section>

        {/* About */}
        <motion.section id="about" {...fadeUp(0.05)} className="mt-12">
          <SectionTitle icon={BookOpen} title="Professional Summary" subtitle="Systems, not prompts" />
          <Card className="rounded-3xl">
            <CardContent className="p-6 text-sm leading-relaxed text-muted-foreground md:text-base">
              I design scalable AI prompt systems that transform objectives into reliable deliverables: advanced prompting (zero-shot, few-shot, CoT), persona engineering, and strict output control. My focus: accuracy, repeatability, and business impact.
            </CardContent>
          </Card>
        </motion.section>

        {/* Skills */}
        <motion.section id="skills" {...fadeUp(0.1)} className="mt-12">
          <SectionTitle icon={Brain} title="Core Skills & Expertise" subtitle="Precision, repeatability, and scale" />
          <div className="grid gap-4 md:grid-cols-3">
            {skills.map((s, i) => (
              <Card key={s.title} className="rounded-3xl">
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <s.icon className="h-5 w-5" /> {s.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    {s.points.map((p) => (
                      <li key={p} className="flex items-start gap-2"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" /> {p}</li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </motion.section>

        {/* Frameworks */}
        <motion.section id="frameworks" {...fadeUp(0.15)} className="mt-12">
          <SectionTitle icon={Layers} title="Frameworks Developed" subtitle="Engineered for dependable results" />
          <div className="grid gap-4 md:grid-cols-3">
            {frameworks.map((f) => (
              <Card key={f.title} className="rounded-3xl">
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <f.icon className="h-5 w-5" /> {f.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0 text-sm text-muted-foreground">
                  <p>{f.body}</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {f.chips.map((c) => (
                      <Badge key={c} variant="outline" className="rounded-2xl">{c}</Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </motion.section>

        {/* Projects with search */}
        <motion.section id="projects" {...fadeUp(0.2)} className="mt-12">
          <SectionTitle icon={Rocket} title="Sample Projects" subtitle="Selected high-impact builds" />

          <Card className="mb-4 rounded-3xl">
            <CardContent className="flex flex-col gap-3 p-4 md:flex-row md:items-center md:justify-between">
              <div className="flex items-center gap-2">
                <Search className="h-4 w-4 text-muted-foreground" />
                <Input placeholder="Filter projects (e.g., YouTube, Business, SEO)" className="w-72 rounded-2xl" />
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Gauge className="h-4 w-4" /> Optimized for: speed, accuracy, and edit-free outputs
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-3">
            {projects.map((p) => (
              <Card key={p.title} className="rounded-3xl">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">{p.title}</CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="mb-3 flex gap-2">
                    {p.metrics.map((m) => (
                      <Badge key={m.label} variant="secondary" className="rounded-2xl">{m.label}: {m.value}</Badge>
                    ))}
                  </div>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    {p.bullets.map((b) => (
                      <li key={b} className="flex items-start gap-2"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" /> {b}</li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </motion.section>

        {/* Case Study */}
        <motion.section id="case-study" {...fadeUp(0.25)} className="mt-12">
          <SectionTitle icon={ShieldCheck} title="Case Study: Before vs After" subtitle="Prompt engineering in action" />
          <div className="grid gap-4 md:grid-cols-2">
            <Card className="rounded-3xl">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Before</CardTitle>
              </CardHeader>
              <CardContent className="pt-0 text-sm text-muted-foreground">
                <blockquote className="rounded-2xl bg-muted p-4">“Write a YouTube script about traveling to Limasawa Island.”</blockquote>
                <p className="mt-3">Result: Generic, flat, lacks hook or emotional pull.</p>
              </CardContent>
            </Card>
            <Card className="rounded-3xl">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">After (ROSES++ + FORMAT-X)</CardTitle>
              </CardHeader>
              <CardContent className="pt-0 text-sm text-muted-foreground">
                <blockquote className="rounded-2xl bg-muted p-4">
                  You are a <strong>travel content strategist</strong> with 10+ years of experience. Create a <strong>6-minute YouTube script</strong> about <strong>Limasawa Island</strong> targeting <strong>Filipino millennials</strong> seeking <strong>budget-friendly travel</strong>. Tone: upbeat, vlog-style. Structure: Hook → Backstory & Fun Facts → Top 5 Attractions → Budget Tips → CTA.
                </blockquote>
                <p className="mt-3">Result: Engaging, structured, highly watchable — 3× higher audience retention.</p>
              </CardContent>
            </Card>
          </div>
        </motion.section>

        {/* Tools */}
        <motion.section id="tools" {...fadeUp(0.3)} className="mt-12">
          <SectionTitle icon={Settings2} title="Tools & Tech Stack" subtitle="What powers the work" />
          <Card className="rounded-3xl">
            <CardContent className="p-6">
              <div className="flex flex-wrap gap-2">
                {tools.map((t) => (
                  <Badge key={t} variant="outline" className="rounded-2xl">{t}</Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.section>

        {/* Contact */}
        <motion.section id="contact" {...fadeUp(0.35)} className="mt-12 mb-16">
          <SectionTitle icon={Mail} title="Contact & Collaboration" subtitle="Let’s build your AI system" />
          <Card className="rounded-3xl">
            <CardContent className="flex flex-col items-start gap-3 p-6 md:flex-row md:items-center md:justify-between">
              <div>
                <div className="text-sm text-muted-foreground">Email</div>
                <a href="mailto:carljarrelarca010@gmail.com" className="font-medium underline-offset-4 hover:underline">carljarrelarca0101@gmail.com</a>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button asChild className="rounded-2xl">
                  <a href="#" aria-label="Open portfolio website">
                    <LinkIcon className="mr-2 h-4 w-4" /> Portfolio Site
                  </a>
                </Button>
                <Button asChild variant="outline" className="rounded-2xl">
                  <a href="#" aria-label="Open LinkedIn profile">
                    <ExternalLink className="mr-2 h-4 w-4" /> LinkedIn
                  </a>
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.section>
      </main>

      {/* Footer */}
      <footer className="border-t">
        <div className="mx-auto max-w-6xl px-4 py-8 text-xs text-muted-foreground">
          © {new Date().getFullYear()} Carl A. • All rights reserved.
        </div>
      </footer>
    </div>
  );
}
