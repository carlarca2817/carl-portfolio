import React from 'react'

export function Badge({ variant='secondary', className='', children }) {
  const variants = {
    secondary: 'bg-gray-100 text-gray-800',
    outline: 'border border-gray-300 text-gray-700'
  }
  return <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs ${variants[variant]} ${className}`}>{children}</span>
}
