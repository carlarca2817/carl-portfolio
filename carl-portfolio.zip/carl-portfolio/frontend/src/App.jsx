import React from 'react'
import PortfolioSite from './Portfolio.jsx'

export default function App() {
  return <PortfolioSite />
}
